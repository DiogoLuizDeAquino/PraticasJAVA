package exercicio4;

public class Animal{
        String nome, raca;

        public Animal(String nome, String raca){
            this.nome = nome;
            this.raca  = raca;
        }

        public String caminhar() {
            return "animal eta caminhando";
        }
    }





