package exercicio4;

import exercicio4.Animal;

public class cachorro extends Animal {


    public cachorro(String nome, String raca) {
        super(nome, raca);
    }
    public String caminhar() {
        return "Cachorro esta caminhando ";
    }
    public String latir()
    {
        return "Au au";
    }
}

