package exercicio5;

public class pobre extends pessoa {
public pobre(String nome, int idade) {

    super(nome, idade);
}
public String trabalha(){
    return("Trabalhe");
}
}
