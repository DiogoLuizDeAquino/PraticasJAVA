package exercicio5;

public class miseravel extends pessoa {

public miseravel(String nome, int idade) {
    super(nome, idade);
}
public String  mendiga(){
    return("Mindingo");
}
}
