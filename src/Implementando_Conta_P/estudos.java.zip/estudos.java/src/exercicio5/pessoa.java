package exercicio5;

public class pessoa {
    private String nome;
    private int idade;

public pessoa(String nome, int idade) {
    this.nome = nome;
    this.idade = idade;

}
}