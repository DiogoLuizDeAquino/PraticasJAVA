package exercicio3;

import exercicio3.Assistente;

public class Tecnico extends Assistente {
    private  int bonus;
    private  int bonusSalario;

    public Tecnico(String nome, String email, String endereco, int telefone, int matricula) {
        super(nome, email, endereco, telefone, matricula);
        this.bonusSalario = bonus;}}

