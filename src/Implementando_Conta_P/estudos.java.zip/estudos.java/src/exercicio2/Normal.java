package exercicio2;

public class Normal extends Ingresso{

    public void imprimeingressoNormal(float valor){
        valor = this.ValorIngresso;

        System.out.println("Ingresso Normal:"+ valor );}
}
